package com.qjjxk.pagergalleryjava;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;


public class GalleryFragment extends Fragment {
    MyViewModel myViewModel;
    ResAdapta resAdapta;
    RecyclerView recyclerView;
    SwipeRefreshLayout swipeRefreshLayout;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_gallery, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        recyclerView = requireActivity().findViewById(R.id.recycle_view);
        swipeRefreshLayout = requireActivity().findViewById(R.id.layout_swipe_refresh);
        myViewModel = new ViewModelProvider(this).get(MyViewModel.class);
        resAdapta = new ResAdapta();
        recyclerView.setAdapter(resAdapta);
        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));

        if (myViewModel.getPhotoListLive().getValue() == null) {
            myViewModel.fetchData();
        }

        myViewModel.getPhotoListLive().observe(getViewLifecycleOwner(), photoItems -> {
            resAdapta.submitList(photoItems);
            swipeRefreshLayout.setRefreshing(false);
        });

        swipeRefreshLayout.setOnRefreshListener(() -> myViewModel.fetchData());
    }
}
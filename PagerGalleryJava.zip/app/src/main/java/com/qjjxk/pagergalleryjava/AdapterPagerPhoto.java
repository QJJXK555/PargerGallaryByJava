package com.qjjxk.pagergalleryjava;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import uk.co.senab.photoview.PhotoView;

public class AdapterPagerPhoto extends ListAdapter<PhotoItem, PagerPhotoViewHodel> {
    protected AdapterPagerPhoto() {
        super(new DiffUtil.ItemCallback<PhotoItem>() {
            @Override
            public boolean areItemsTheSame(@NonNull PhotoItem oldItem, @NonNull PhotoItem newItem) {
                return oldItem.photoId == newItem.photoId;
            }

            @Override
            public boolean areContentsTheSame(@NonNull PhotoItem oldItem, @NonNull PhotoItem newItem) {
                return oldItem.fullUrl.equals(newItem.fullUrl);
            }
        });
    }

    @NonNull
    @Override
    public PagerPhotoViewHodel onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.pager_photo_view, parent, false);
        return new PagerPhotoViewHodel(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull PagerPhotoViewHodel holder, int position) {
        Glide.with(holder.itemView)
                .load(getItem(position).fullUrl)
                .placeholder(R.drawable.ic_baseline_insert_photo_24)
                .into(holder.photoView);
    }
}

class PagerPhotoViewHodel extends RecyclerView.ViewHolder {
    PhotoView photoView;
    public PagerPhotoViewHodel(@NonNull View itemView) {
        super(itemView);
        photoView = itemView.findViewById(R.id.img_full_photo);
    }
}
